import ij.*;
import ij.gui.*;
import ij.process.*;
import java.awt.*;
import java.awt.event.*;

// Align_4 v1.0  by G.Landini 12/Aug/2004
// 1.1 24/6/2005 corrected window closing
// 1.2 ??? some bug fix? I can't remember
// 1.3 21/Sep/2006 added transparency, stamps in correct order, correct BW switch, fiducial point alignment
// 1.4 30/May/2022 added logging of the tope left coordinates when pressing Help.

public class Align_4 extends Dialog
implements ActionListener, AdjustmentListener, ItemListener, WindowListener, Runnable {

	private Thread threadProcess = null;

	protected int par1 = 1, imageSelected = 0, imgt=0, roix, roiy, roiw, roih;
	protected ImagePlus imp, imp2;
	protected ImageProcessor ip, ip2;
	protected int x, y, extra;
	protected int[] index = new int[4];
	protected int[] width = new int[4];
	protected int[] height = new int[4];
	protected int[] ox = new int[4];
	protected int[] oy = new int[4];
	protected boolean [] imreal = new boolean[4];
	protected int[][] image0;
	protected int[][] image1;
	protected int[][] image2;
	protected int[][] image3;
	protected int[] order = {1, 2, 3, 0};
	protected boolean inv = false;
	protected int maxwidth=-1;
	protected int maxheight=-1;	
	protected boolean cropped = false;
	protected boolean transparent = false;


	public Align_4 () {
		super(new Frame(), "Align 4");
		if (IJ.versionLessThan("1.21a"))
			return;

		imp = WindowManager.getCurrentImage();
		if (imp == null) {
			IJ.showMessage("Align 4","This plugin requires 1 to 4 images.");
			return;
		}
	
		int[] wList = WindowManager.getIDList();
		String[] titles = new String[wList.length+1];
		
		for (int i=0; i<wList.length; i++) {
			imp = WindowManager.getImage(wList[i]);
			titles[i] = imp!=null?imp.getTitle():"";
		}
		String none = "*None*";
		titles[wList.length] = none;

		GenericDialog gd = new GenericDialog("Align 4");
		gd.addMessage("Images to align");
		gd.addChoice("Top Left [1]:", titles, titles[0]);
		gd.addChoice("Top Right [2]:", titles, titles[1]);
		String title3 = titles.length>2?titles[2]:none;
		gd.addChoice("Bottom Left [3]:", titles, title3);
		String title4 = titles.length>3?titles[3]:none;
		gd.addChoice("Bottom Right [4]:", titles, title4);
		gd.addCheckbox("Keep source images", true);
		gd.addNumericField ("Extra space", 0, 0);
	
		gd.showDialog();
		if (gd.wasCanceled())
			return;

		index[0] = gd.getNextChoiceIndex();
		index[1] = gd.getNextChoiceIndex();
		index[2] = gd.getNextChoiceIndex();
		index[3] = gd.getNextChoiceIndex();
		boolean keep = gd.getNextBoolean();
		extra = (int) gd.getNextNumber();

		ImagePlus[] image = new ImagePlus[4];

		for (int i=0; i<4; i++) {
			if (index[i]<wList.length)
				image[i] = WindowManager.getImage(wList[index[i]]);
		}

		for (int i=0; i<4; i++) {
			ImagePlus img = image[i];
			if (img!=null) {
				width[i]=img.getWidth();
				height[i]=img.getHeight();
			}
		}
		//IJ.log(" "+maxwidth+" "+maxheight);

		image0= new int[width[0]][height[0]];
		image1= new int[width[1]][height[1]];
		image2= new int[width[2]][height[2]];
		image3= new int[width[3]][height[3]];

		ImageProcessor ip;

		ImagePlus img = image[0];
		if (img!=null) {
			imreal[0]=true;
			ip = img.getProcessor();
			imgt = imp.getType();
			for (y=0;y<height[0];y++){
				for(x=0;x<width[0];x++)
					image0[x][y]=ip.getPixel(x,y);
			}
			if(!keep) img.hide();
		}

		img = image[1];
		if (img!=null) {
			imreal[1]=true;
			ip = img.getProcessor();
			for (y=0;y<height[1];y++){
				for(x=0;x<width[1];x++)
					image1[x][y]=ip.getPixel(x,y);
			}
			if(!keep) img.hide();
		}

		img = image[2];
		if (img!=null) {
			imreal[2]=true;
			ip = img.getProcessor();
			for (y=0;y<height[2];y++){
				for(x=0;x<width[2];x++)
					image2[x][y]=ip.getPixel(x,y);
			}
			if(!keep) img.hide();
		}
		
		img = image[3];
		if (img!=null) {
			imreal[3]=true;
			ip = img.getProcessor();
			for (y=0;y<height[3];y++){
				for(x=0;x<width[3];x++)
					image3[x][y]=ip.getPixel(x,y);
			}
			if(!keep) img.hide();
		}
		
		// find necessary canvas size
		if (width[0]+width[1] > maxwidth) maxwidth = width[0]+width[1];
		if (width[0]+width[3] > maxwidth) maxwidth = width[0]+width[3];
		if (width[2]+width[1] > maxwidth) maxwidth = width[2]+width[1];
		if (width[2]+width[3] > maxwidth) maxwidth = width[2]+width[3];
		
		if (height[0]+height[2] > maxheight) maxheight = height[0]+height[2];
		if (height[0]+height[3] > maxheight) maxheight = height[0]+height[3];
		if (height[2]+height[1] > maxheight) maxheight = height[2]+height[1];
		if (height[2]+height[3] > maxheight) maxheight = height[2]+height[3];

		maxheight += extra;
		maxwidth += extra;
		//IJ.log(" "+maxwidth+" "+maxheight);
		
		// find out what image to create
		if (imgt==0)
			imp2 = NewImage.createByteImage("Aligned", maxwidth, maxheight, 1, 0);
		// 16 bit: alignment OK, but problems with LUTs in different images.
		//else if (temp==1)
		//	imp2 = NewImage.createShortImage("Aligned", maxwidth, maxheight, 1, 0);
		else if (imgt==4)
				imp2 = NewImage.createRGBImage("Aligned", maxwidth, maxheight, 1, 0);
		else{
			IJ.showMessage("Align 4","Images must be 8-bit grey or RGB.");
			return;
		}

		ip2 = imp2.getProcessor();
		ip2.fill();
		imp2.show();
		
		if (imreal[0]){
			 ox[0]=0;
			 oy[0]=0;
			for (y=0;y<height[0];y++){
				for(x=0;x<width[0];x++)
					ip2.putPixel(x,y, image0[x][y]);
			}
		}
		if (imreal[1]){
			 ox[1]=width[0]>width[2]?width[0]:width[2];
			 oy[1]=0;
			for (y=0;y<height[1];y++){
				for(x=0;x<width[1];x++)
					ip2.putPixel(x+ox[1],y, image1[x][y]);
			}
		}
		if (imreal[2]){
			 ox[2]=0;
			 oy[2]=height[0]>height[1]?height[0]:height[1];
			for (y=0;y<height[2];y++){
				for(x=0;x<width[2];x++)
					ip2.putPixel(x,y+oy[2], image2[x][y]);
			}
		}
		if (imreal[3]){
			 ox[3]=width[0]>width[2]?width[0]:width[2];
			 oy[3]=height[0]>height[1]?height[0]:height[1];
			for (y=0;y<height[3];y++){
				for(x=0;x<width[3];x++)
					ip2.putPixel(x+ox[3],y+oy[3], image3[x][y]);
			}
		}
		imp2.updateAndDraw();	
		doDialog();
	}


	public void run() {
		// You will never be here...
	}

	void tralign(){
		int nx, ny, temp;
		IJ.run("Select All");
		ip2.fill();
		if (inv)
			IJ.run("Invert");
		temp = imageSelected;
		for(int m=0;m<4;m++){
			if (m!=temp){
				imageSelected = m;
				align();
			}
		}
		imageSelected = temp;
		IJ.run("Select None");

		if (imgt==0){
			if (imageSelected==0){
				if (imreal[0]){
					for (y=0;y<height[0];y++){
						ny=y+oy[0];
						for(x=0;x<width[0];x++)
							ip2.putPixel(x+ox[0],ny, (ip2.getPixel(x+ox[0],ny) + image0[x][y])/2);
					}
				}
			}

			if (imageSelected==1){
				if (imreal[1]){
					for (y=0;y<height[1];y++){
						ny=y+oy[1];
						for(x=0;x<width[1];x++)
							ip2.putPixel(x+ox[1],ny, (ip2.getPixel(x+ox[1],ny)+ image1[x][y])/2);
					}
				}
			}

			if (imageSelected==2){
				if (imreal[2]){
					for (y=0;y<height[2];y++){
						ny=y+oy[2];
						for(x=0;x<width[2];x++)
							ip2.putPixel(x+ox[2],ny, (ip2.getPixel(x+ox[2],ny) + image2[x][y])/2);
					}
				}
			}

			if (imageSelected==3){
				if (imreal[3]){
					for (y=0;y<height[3];y++){
						ny=y+oy[3];
						for(x=0;x<width[3];x++)
							ip2.putPixel(x+ox[3],ny, (ip2.getPixel(x+ox[3],ny)+ image3[x][y])/2);
					}
				}
			}
		}
		else{

			int red, gre, blu, col=0, imared, imagre=0, imablu=0;
			if (imageSelected==0){
				if (imreal[0]){
					for (y=0;y<height[0];y++){
						ny=y+oy[0];
						for(x=0;x<width[0];x++){
							nx=x+ox[0];
							col = ip2.getPixel(nx,ny);
							red=((col & 0xff0000)>>16);
							gre=((col & 0x00ff00)>>8);
							blu =(col & 0x0000ff);
							col=image0[x][y];
							imared=(col & 0xff0000)>>16;
							imagre=(col & 0x00ff00)>>8;
							imablu =col & 0x0000ff;
							col=( (((int)((red+imared)/2) & 0xff) <<16)+ (((int)((gre+imagre)/2) & 0xff) << 8) +  ((int)((blu+imablu)/2) & 0xff));
							ip2.putPixel(nx,ny,col);
							//ip2.putPixel(x+ox[0],ny, (ip2.getPixel(x+ox[0],ny) + image0[x][y])/2);
						}
					}
				}
			}

			if (imageSelected==1){
				if (imreal[1]){
					for (y=0;y<height[1];y++){
						ny=y+oy[1];
						for(x=0;x<width[1];x++){
							nx=x+ox[1];
							col = ip2.getPixel(nx,ny);
							red=((col & 0xff0000)>>16);
							gre=((col & 0x00ff00)>>8);
							blu =(col & 0x0000ff);
							col=image1[x][y];
							imared=(col & 0xff0000)>>16;
							imagre=(col & 0x00ff00)>>8;
							imablu =col & 0x0000ff;
							col=( (((int)((red+imared)/2) & 0xff) <<16)+ (((int)((gre+imagre)/2) & 0xff) << 8) +  ((int)((blu+imablu)/2) & 0xff));
							ip2.putPixel(nx,ny,col);
							//ip2.putPixel(x+ox[1],ny, (ip2.getPixel(x+ox[1],ny)+ image1[x][y])/2);
						}
					}
				}
			}

			if (imageSelected==2){
				if (imreal[2]){
					for (y=0;y<height[2];y++){
						ny=y+oy[2];
						for(x=0;x<width[2];x++){
							nx=x+ox[2];
							col = ip2.getPixel(nx,ny);
							red=((col & 0xff0000)>>16);
							gre=((col & 0x00ff00)>>8);
							blu =(col & 0x0000ff);
							col=image2[x][y];
							imared=(col & 0xff0000)>>16;
							imagre=(col & 0x00ff00)>>8;
							imablu =col & 0x0000ff;
							col=( (((int)((red+imared)/2) & 0xff) <<16)+ (((int)((gre+imagre)/2) & 0xff) << 8) +  ((int)((blu+imablu)/2) & 0xff));
							ip2.putPixel(nx,ny,col);
							//ip2.putPixel(x+ox[2],ny, (ip2.getPixel(x+ox[2],ny) + image2[x][y])/2);
						}
					}
				}
			}

			if (imageSelected==3){
				if (imreal[3]){
					for (y=0;y<height[3];y++){
						ny=y+oy[3];
						for(x=0;x<width[3];x++){
							nx=x+ox[3];
							col = ip2.getPixel(nx,ny);
							red=((col & 0xff0000)>>16);
							gre=((col & 0x00ff00)>>8);
							blu =(col & 0x0000ff);
							col=image3[x][y];
							imared=(col & 0xff0000)>>16;
							imagre=(col & 0x00ff00)>>8;
							imablu =col & 0x0000ff;
							col=( (((int)((red+imared)/2) & 0xff) <<16)+ (((int)((gre+imagre)/2) & 0xff) << 8) +  ((int)((blu+imablu)/2) & 0xff));
							ip2.putPixel(nx,ny,col);
							//ip2.putPixel(x+ox[3],ny, (ip2.getPixel(x+ox[3],ny)+ image3[x][y])/2);
						}
					}
				}
			}

		}

		imp2.updateAndDraw();
	}


	void align(){
		int nx, ny;
		if (imageSelected==0){
			if (imreal[0]){
				for (y=0;y<height[0];y++){
					ny=y+oy[0];
					for(x=0;x<width[0];x++)
						ip2.putPixel(x+ox[0],ny, image0[x][y]);
				}
			}
		}

		if (imageSelected==1){
			if (imreal[1]){
				for (y=0;y<height[1];y++){
					ny=y+oy[1];
					for(x=0;x<width[1];x++)
						ip2.putPixel(x+ox[1],ny, image1[x][y]);
				}
			}
		}

		if (imageSelected==2){
			if (imreal[2]){
				for (y=0;y<height[2];y++){
					ny=y+oy[2];
					for(x=0;x<width[2];x++)
						ip2.putPixel(x+ox[2],ny, image2[x][y]);
				}
			}
		}

		if (imageSelected==3){
			if (imreal[3]){
				for (y=0;y<height[3];y++){
					ny=y+oy[3];
					for(x=0;x<width[3];x++)
						ip2.putPixel(x+ox[3],ny, image3[x][y]);
				}
			}
		}
		imp2.updateAndDraw();
	}


	// Build the dialog box.
	private GridBagLayout layout;
	private GridBagConstraints constraint;
	private Button bnTrans;
	private Button bnMouse;
	private Button bnHelp;
	private Button bnUp;
	private Button bnDn;
	private Button bnRt;
	private Button bnLt;
	private Button bnClean;
	private Button bnBW;
	private Button bnCrop;
	private Button bnStamp;
	private TextField txtpar1;
	private Scrollbar scrpar1;
	private Checkbox i1;
	private Checkbox i2;
	private Checkbox i3;
	private Checkbox i4;
	private CheckboxGroup imageGroup;

	private void doDialog() {
		// LayoutIJ.log("1")
		layout = new GridBagLayout();
		constraint = new GridBagConstraints();
		bnTrans = new Button("Transp.");
		bnMouse = new Button("Fiducial");
		bnHelp = new Button("Help");
		bnUp = new Button("Up");
		bnDn = new Button("Down");
		bnRt = new Button("Right");
		bnLt = new Button("Left");
		bnStamp = new Button("Stamp");
		bnClean = new Button("Clean");
		bnBW = new Button("B/W");
		bnCrop = new Button("Trim");

		txtpar1 = new TextField(""+par1, 3);
		scrpar1	= new Scrollbar(Scrollbar.HORIZONTAL, 1, 1, 1, 101);
		i1 = new Checkbox("1");
		i2 = new Checkbox("2");
		i3 = new Checkbox("3");
		i4 = new Checkbox("4");

		imageGroup 	= new CheckboxGroup();
		i1.setCheckboxGroup(imageGroup);
		i2.setCheckboxGroup(imageGroup);
		i3.setCheckboxGroup(imageGroup);
		i4.setCheckboxGroup(imageGroup);
		if (imreal[0])
			i1.setState(true);
		else if (imreal[1])
			i2.setState(true);
		else if (imreal[2])
			i3.setState(true);
		else if (imreal[3])
			i4.setState(true);


		// Panel parameters
		Panel pnMain = new Panel();
		pnMain.setLayout(layout);

		addComponent(pnMain, 0, 0, 1, 1, 2, new Label("   Shift:"));
		addComponent(pnMain, 0, 1, 1, 1, 2, txtpar1);
		addComponent(pnMain, 0, 2, 1, 1, 2, scrpar1);
		addComponent(pnMain, 3, 1, 1, 1, 5, bnUp);
		addComponent(pnMain, 4, 0, 1, 1, 5, bnLt);
		addComponent(pnMain, 4, 1, 1, 1, 5, bnStamp);
		addComponent(pnMain, 4, 2, 1, 1, 5, bnRt);
		addComponent(pnMain, 5, 1, 1, 1, 5, bnDn);
		addComponent(pnMain, 6, 0, 1, 1, 2, new Label("  Image:"));
		addComponent(pnMain, 6, 1, 1, 1, 2, i1);
		addComponent(pnMain, 6, 2, 1, 1, 2, i2);
		addComponent(pnMain, 7, 1, 1, 1, 2, i3);
		addComponent(pnMain, 7, 2, 1, 1, 2, i4);
		addComponent(pnMain, 8, 0, 1, 1, 2, bnTrans);
		addComponent(pnMain, 8, 1, 1, 1, 2, bnClean);
		addComponent(pnMain, 8, 2, 1, 1, 2, bnBW);
		addComponent(pnMain, 9, 0, 1, 1, 2, bnMouse);
		addComponent(pnMain, 9, 1, 1, 1, 2, bnCrop);
		addComponent(pnMain, 9, 2, 1, 1, 5, bnHelp);

		// Add Listenersaligned
		bnUp.addActionListener(this);
		bnDn.addActionListener(this);
		bnRt.addActionListener(this);
		bnLt.addActionListener(this);
		bnClean.addActionListener(this);
		bnBW.addActionListener(this);
		bnCrop.addActionListener(this);
		bnStamp.addActionListener(this);
		bnTrans.addActionListener(this);
		bnMouse.addActionListener(this);
		bnHelp.addActionListener(this);
		scrpar1.addAdjustmentListener(this);
		scrpar1.setUnitIncrement(1);
		i1.addItemListener(this);
		i2.addItemListener(this);
		i3.addItemListener(this);
		i4.addItemListener(this);
		addWindowListener(this);
		// Build panel
		add(pnMain);
		pack();
		setResizable(false);
		GUI.center(this);
		setVisible(true);
		IJ.wait(250); // work around for Sun/WinNT bug

		if (!imreal[0]) i1.setEnabled(false);
		if (!imreal[1]) i2.setEnabled(false);
		if (!imreal[2]) i3.setEnabled(false);
		if (!imreal[3]) i4.setEnabled(false);
	}

	final private void addComponent(
	final Panel pn,
	final int row, final int col,
	final int width, final int height,
	final int space,
	final Component comp) {
		constraint.gridx = col;
		constraint.gridy = row;
		constraint.gridwidth = width;
		constraint.gridheight = height;
		constraint.anchor = GridBagConstraints.NORTHWEST;
		constraint.insets = new Insets(space, space, space, space);
		constraint.weightx = IJ.isMacintosh()?90:100;
		constraint.fill = constraint.HORIZONTAL;
		layout.setConstraints(comp, constraint);
		pn.add(comp);
	}

	// Implement the listeners
	public synchronized void adjustmentValueChanged(AdjustmentEvent e) {
		if (e.getSource() == scrpar1) {
			//System.out.println("Event: " + e);
			par1=scrpar1.getValue();
			txtpar1.setText( "" + par1);
		}
		notify();
    }

	public synchronized void itemStateChanged(ItemEvent e) {
		int m, n;
		if (e.getSource() == i1) {
			imageSelected = 0;
		}
		else if (e.getSource() == i2) {
			imageSelected = 1;
		}
		else if (e.getSource() == i3) {
			imageSelected = 2;
		}
		else if (e.getSource() == i4) {
			imageSelected = 3;
		}

		for(m=0;m<4;m++){
			if(order[m]==imageSelected)
				break;
		}
		for (n=m; n<3;n++){
			order[n]=order[n+1];
		}
		order[3]=imageSelected;
		//IJ.log("Order:"+ order[0]+" "+order[1]+" "+order[2]+" "+order[3]);

		IJ.showStatus("Image:"+(imageSelected+1)+",  x:"+ox[imageSelected]+", y:"+oy[imageSelected]);
		notify();
	}

	public synchronized  void actionPerformed(ActionEvent e) {
		if (e.getSource() == bnTrans) {
			if (transparent==false) {
				transparent=true;
				bnTrans.setLabel("Opaque");
				tralign();
			}
			else{
				transparent=false;
				bnTrans.setLabel("Transp.");
				align();
			}
		}
		else if (e.getSource() == bnMouse){
			IJ.showStatus("Mouse method");
			Line line = (Line)imp2.getRoi();
			if (line==null)
				IJ.error("A Line Selection from a Landmark point in\nthe active image to a Target point is required.");
			else{
				//IJ.log("makeLine "+line.x1+ " "+ line.y1+" "+ line.x2+" "+ line.y2);
				ox[imageSelected]+=(line.x2-line.x1);
				oy[imageSelected]+=(line.y2-line.y1);
				if (transparent)
					tralign();
				else
					align();
			}
		}
		else if (e.getSource() == bnStamp){
			align();
		}
		else if (e.getSource() == bnClean){
			IJ.run("Select All");
			ip2.fill();
			if (inv)
				IJ.run("Invert");
			IJ.run("Select None");
			for (int m=0;m<4;m++){
				imageSelected = order[m];
				align();
			}
			bnTrans.setLabel("Transp.");
			transparent=false;
		}
		else if (e.getSource() == bnBW){
			if (!cropped){
				IJ.run("Select All");
				ip2.fill();	
				if (inv)
					inv = false;
				else{
					inv=true;
					IJ.run("Invert");
				}
				IJ.run("Select None");

				for (int m=0;m<3;m++){
					imageSelected = order[m];
					align();
				}
				imageSelected = order[3];
				if (transparent)
					tralign();
				else
					align();
			}
		}
		
		else if (e.getSource() == bnCrop){
			if (!cropped){
				roix=100000000; //surely not such a big image
				roiy=100000000;
				roiw=-1;
				roih=-1;
				for (int i=0; i<4;i++){
					if (imreal[i]){
						if (ox[i]< roix) roix =ox[i];
						if (oy[i]< roiy) roiy =oy[i];
						if (ox[i]+ width[i] > roiw) roiw = ox[i]+ width[i];
						if (oy[i]+ height[i]> roih) roih = oy[i]+ height[i];
					}
				}
				if (roix<0) roix=0;
				if (roiy<0) roiy=0;
				if (roih>maxheight) roih=maxheight;
				if (roiw>maxwidth) roiw=maxwidth;
				IJ.makeRectangle(roix, roiy, roiw-roix, roih-roiy);
				IJ.run("Crop");
				cropped=true;
				bnCrop.setEnabled(false);
				bnBW.setEnabled(false);
				bnTrans.setEnabled(false);
				bnClean.setEnabled(false);
				bnMouse.setEnabled(false);
			}
		}
		
		else if (e.getSource() == bnUp){ //up
			oy[imageSelected]-=par1;
			if (transparent)
				tralign();
			else
				align();
		}
		else if (e.getSource() == bnDn){ //dn
			oy[imageSelected]+=par1;
			if (transparent)
				tralign();
			else
				align();
		}
		else if (e.getSource() == bnRt){ //right
			ox[imageSelected]+=par1;
			if (transparent)
				tralign();
			else
				align();
		}
		else if (e.getSource() == bnLt){ //left
			ox[imageSelected]-=par1;
			if (transparent)
				tralign();
			else
				align();
		}
		else if (e.getSource() == bnHelp) {
			for (int i=0; i<4;i++) IJ.log("Image "+ (i+1) +" ["+ ox[i]+", "+oy[i]+"]");
			IJ.log("---");
			IJ.showMessage("Help","Align 4  v1.4  by G. Landini\n"+
							"Manual alignment/stitching of up to 4 images. Supported image types\n"+
							"are: 8-bit grey & RGB. Image [1] determines the aligned image type.\n"+
							"To align different image types convert all images to RGB.\n"+
							"For fiducial point alignment, use a line selection to connect the\n"+
							"fiducial points in the image you want to move [must be selected with\n"+
							"the radio buttons] to the same point in another part of the image. Then\n"+
							"press the [Fiducial] button. You can then make small adjustments with the\n"+
							"Up Down Left and Right buttons.\n"+
							"This Help button also reports the x,y coordinates of the top left corner\n"+
							"of the images in the untrimmed result.\n"+
							"Once the image is trimmed, no further editing is possible.\n");
		}
		IJ.showStatus("Image:"+(imageSelected+1)+",  x:"+ox[imageSelected]+", y:"+oy[imageSelected]);
		imp2.updateAndDraw();
		notify();
	}


	public void windowActivated(WindowEvent e) {
	}

	public void windowClosing(WindowEvent e) {
		dispose();	
	}

	public void windowClosed(WindowEvent e) {
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e){
	}

	public void windowIconified(WindowEvent e){
	}

	public void windowOpened(WindowEvent e){
	}
}
